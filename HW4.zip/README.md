# Hw4-TF-DF-IDF

Write an application for calculating:
  - Document frequency (DF)
  - Inverse document frequency (IDF)
of a given term in a collection. The interface of the application should allow the user to enter a term and to obtain its DF and IDF. Additionally, a term and a document id could be entered in order to obtain the term's frequency (tf) in that document. 
