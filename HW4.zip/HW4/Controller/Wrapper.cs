﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4.Controller
{
    class Wrapper
    {
        public void LoadFile(String path)
        {

        }

        public void DocumentFrequency(String Term)
        {

        }
        public void InverseDocumentFrequency(String Term)
        {

        }

    }
}
